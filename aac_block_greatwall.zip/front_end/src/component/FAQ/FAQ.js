export const faqQuestions = [
        {
            question: "How many programmers does it take to screw a lightbulb?",
            answer:
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pharetra lorem eu dolor rhoncus, at scelerisque ligula gravida. Sed porta id mi sit amet convallis. Etiam iaatis quam."
        },
        {
            question: "Who is the most awesome person?",
            answer: "You! The viewer!"
        },
        {
            question:
                "How many questions does it take to makes a succesful FAQ Page?",
            answer: "This many!"
        }
    ]
