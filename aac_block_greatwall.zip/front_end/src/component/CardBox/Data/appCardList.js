import appImg1 from '../../../img/Applications/A.Residential.png';
import appImg2 from '../../../img/Applications/b.Commercial.png';
import appImg3 from '../../../img/Applications/c.Hospital.png';
import appImg4 from '../../../img/Applications/d.Plant.png';
import appImg5 from '../../../img/Applications/e.Education.png';
import appImg6 from '../../../img/Applications/f.Resturant.png';
import appImg7 from '../../../img/Applications/g.Hotel.png';
import appImg8 from '../../../img/Applications/h.Power-Plant.png';

export const appCardList = [
    { title: "Residential Buildings", imgUrl: appImg1},
    { title: "Commercial Buildings", imgUrl: appImg2},
    { title: "Hospitals", imgUrl: appImg3 },
    { title: "Factories & Warehouses", imgUrl: appImg4 },
    { title: "Educational Institutes", imgUrl: appImg5 },
    { title: "Restaurant", imgUrl: appImg6 },
    { title: "Hotel", imgUrl: appImg7 },
    { title: "Power Plant", imgUrl: appImg8 },
]