const ImgToIcon = (props) => {
    return (
        <img src={props.img} height={props.fontSize} alt="icon" />
    );
};

export default ImgToIcon;